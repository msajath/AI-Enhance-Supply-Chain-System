/**
 * Line drawing of a construction site for the sign-in page: tower crane lowering a
 * steel bundle (the only yellow element), a building frame going up, stacked
 * materials and a delivery truck. Lines draw themselves once on load (see
 * `.site-art` in index.css); with reduced motion it appears instantly.
 */
export function SiteIllustration() {
  // `pathLength={1}` lets CSS animate every line with the same dash values.
  const L = { pathLength: 1 } as const;
  return <svg className="site-art" viewBox="0 0 640 520" role="img" aria-label="Line drawing of a construction site with a tower crane, a building frame and a delivery truck">
    <g className="art-lines" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      {/* ground */}
      <path {...L} d="M24 452H628" />
      <path {...L} className="faint" d="M24 462H628" strokeDasharray="2 10" />

      {/* tower crane: mast */}
      <path {...L} d="M150 452V96M174 452V96" />
      <path {...L} className="faint" d="M150 452 174 420 150 388 174 356 150 324 174 292 150 260 174 228 150 196 174 164 150 132 174 100" />
      <path {...L} d="M138 452H186" />
      {/* jib, counter-jib, apex and ties */}
      <path {...L} d="M78 96H560M78 110H186M186 96V110" />
      <path {...L} className="faint" d="M186 96 210 110 234 96 258 110 282 96 306 110 330 96 354 110 378 96 402 110 426 96 450 110 474 96 498 110 522 96 546 110 560 96" />
      <path {...L} d="M186 110H560" />
      <path {...L} d="M162 96V52M162 52 560 96M162 52 78 96" />
      <rect {...L} x="82" y="112" width="40" height="26" rx="2" />
      <rect {...L} x="146" y="116" width="32" height="22" rx="3" />
      {/* trolley + cable */}
      <rect {...L} x="384" y="110" width="28" height="10" rx="2" />
      <path {...L} className="cable" d="M398 120V238" />

      {/* building frame going up */}
      <path {...L} d="M262 452V244M322 452V244M382 452V292M442 452V292M502 452V340" />
      <path {...L} d="M262 404H502M262 356H502M262 308H442M262 260H322" />
      <path {...L} className="faint" d="M322 404 382 356M382 404 442 356M442 404 502 356M262 356 322 308M322 356 382 308" />
      {/* scaffold ladder on the left side */}
      <path {...L} className="faint" d="M246 452V250M254 452V250M246 428H254M246 404H254M246 380H254M246 356H254M246 332H254M246 308H254M246 284H254M246 260H254" />

      {/* materials: cement bags + rebar bundle */}
      <rect {...L} x="36" y="430" width="34" height="22" rx="5" />
      <rect {...L} x="72" y="430" width="34" height="22" rx="5" />
      <rect {...L} x="54" y="408" width="34" height="22" rx="5" />
      <path {...L} d="M196 446H246M196 440H246M196 434H246" />
      <path {...L} className="faint" d="M206 452V430M236 452V430" />

      {/* delivery truck */}
      <path {...L} d="M520 452V424M520 424H572V452" />
      <path {...L} d="M572 424V398H600L618 418V452" />
      <path {...L} d="M578 404H598L610 418H578Z" />
      <circle {...L} cx="540" cy="452" r="11" />
      <circle {...L} cx="598" cy="452" r="11" />
      <path {...L} className="faint" d="M526 416H566M530 410H562" />
    </g>

    {/* the load: steel bundle being lowered, the single accent */}
    <g className="art-load">
      <path d="M398 238 380 254M398 238 416 254" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <rect x="364" y="254" width="68" height="16" rx="2" />
      <path d="M370 262H426" stroke="rgba(31,36,41,.35)" strokeWidth="1.2" />
    </g>
  </svg>;
}
