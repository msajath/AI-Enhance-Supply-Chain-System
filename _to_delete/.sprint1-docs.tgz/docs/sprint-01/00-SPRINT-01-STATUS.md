# Sprint 01 — Status & Completion Checklist

**Sprint:** 01 Requirements and validation (handbook Days 001–010)
**Gate (handbook p.4):** *Validated scope, assumptions, success cases and design sign-off.*
**Last updated:** 2026-11-05

## 1. Audit result (before this update)

| Expected Sprint 1 output (handbook) | Found in repo on 2026-11-05? |
| :--- | :--- |
| `docs/decision-log.md` (edited by all 40 cards) | ❌ Missing |
| `evidence/sprint-01/day-001…010/member-1…4/notes.md` (40 notes) | ❌ Missing |
| Interview sheets, swimlanes, data fields, permission matrix, test cases, NFRs, ERD review, user stories, fixtures, review packet, demo record | ❌ Missing |
| Repository / Jira structure (Day 001, M4) | ✅ Repo, branches and CI exist; Jira not evidenced |

**Conclusion:** Sprint 1 was **not complete**. The team had moved straight to code: auth, health API, a 6-table migration, CI and a frontend shell. In the handbook that is Sprint 2 ("Foundation and access") work. The code has been left as is. This update adds only the Sprint 1 artefacts.

## 2. Status after this update

| Day | Theme | M1 | M2 | M3 | M4 |
| :- | :--- | :-: | :-: | :-: | :-: |
| 001 | Discovery prep / scope register | 📝 | 📝 | 📝 | 📝 |
| 002 | Interviews / consolidation | ⏳ | ⏳ | ⏳ | 📝 |
| 003 | Swimlanes / context & architecture | 📝 | 📝 | 📝 | 📝 |
| 004 | Data fields / permission matrix & API | 📝 | 📝 | 📝 | 📝 |
| 005 | Acceptance & test cases / NFRs | 📝 | 📝 | 📝 | 📝 |
| 006 | ERD review / naming & boundaries | 📝 | 📝 | 📝 | 📝 |
| 007 | User stories / Jira epics | 📝 | 📝 | 📝 | 📝 |
| 008 | Fixtures / governance | 📝 | 📝 | 📝 | 📝 |
| 009 | Peer review / review packet | ⏳ | ⏳ | ⏳ | 📝 |
| 010 | Mentor review / demo | ⏳ | ⏳ | ⏳ | ⏳ |

📝 = written artefact and open questions ready; needs a peer-review link · ⏳ = needs a human event (an interview, a review meeting or the mentor session)

## 3. "Done when" checklist (every card: written artefact + explicit unresolved questions + group review link)

- [x] Written artefact for every card (`docs/sprint-01/01…11`)
- [x] Unresolved questions are explicit (`decision-log.md` §3: 19 questions; §2: 15 assumptions)
- [x] Evidence note for each of the 40 cards (`evidence/sprint-01/…`)
- [ ] Day 002 stakeholder interviews held and answers recorded (`02` sheets have blank answer columns)
- [ ] Group review link (PR URL) added to each evidence note
- [ ] Day 009 cross-review results ticked (`10` §3)
- [ ] Mentor Sprint 1 review held and feedback recorded (`11` §3)
- [ ] Jira epics E01–E08 created in the real Jira workspace

**What the team does next:** open one PR with these documents and have every member review it. Hold the interviews and the mentor review. Fill in the blanks. Then tick the last five boxes. After that, Sprint 1 can be signed off.

## 4. Out of Sprint 1 scope (deliberately not done)

No Sprint 2+ features were built (no new modules, migrations or endpoints). The only code change in this update is the **frontend visual refresh** (`frontend/src/index.css` plus small markup additions in `App.tsx`), which the team asked for separately.
