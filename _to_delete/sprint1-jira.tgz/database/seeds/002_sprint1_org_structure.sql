-- ==============================================================================
-- QORVENZ TECH — SPRINT 1 SEED: projects, sites, departments, warehouses
-- Jira: AESCS-41 / AESCS-161 (Member 2) · fixture plan: docs/sprint-01/09 (D-012)
-- Synthetic demo data only. Safe to re-run: every insert is keyed on a business
-- code and references parents by code, so no duplicates and no dangling IDs.
-- Users and their access grants are created by scripts/seed.ts (no shared passwords).
-- ==============================================================================

-- Company (exists from 001; repeated here so this file can run on its own)
INSERT INTO organizations (id, name, code, address)
VALUES ('a0000000-0000-0000-0000-000000000001', 'Qorvenz Construction Infrastructure Ltd.', 'QOR-HQ-01', '100 Engineering Blvd, Colombo')
ON CONFLICT (code) DO NOTHING;

-- Departments / cost centres
INSERT INTO departments (organization_id, code, name, cost_center_code)
SELECT o.id, d.code, d.name, d.cc
FROM organizations o
CROSS JOIN (VALUES
  ('PROC', 'Procurement',             'CC-100'),
  ('WHL',  'Warehouse & Logistics',   'CC-200'),
  ('SITE', 'Site Operations',         'CC-300'),
  ('FIN',  'Finance & Cost Control',  'CC-400')
) AS d(code, name, cc)
WHERE o.code = 'QOR-HQ-01'
ON CONFLICT (organization_id, code) DO NOTHING;

-- Projects (2 per D-012)
INSERT INTO projects (id, organization_id, code, name, status, start_date, end_date)
SELECT p.id::uuid, o.id, p.code, p.name, p.status, p.start_date::date, p.end_date::date
FROM organizations o
CROSS JOIN (VALUES
  ('e0000000-0000-0000-0000-000000000001', 'PRJ-CMB-01', 'Colombo Port City — Tower B',          'ACTIVE', '2026-01-15', '2027-12-31'),
  ('e0000000-0000-0000-0000-000000000002', 'PRJ-GAL-02', 'Galle Southern Expressway Interchange', 'ACTIVE', '2026-03-01', '2027-06-30')
) AS p(id, code, name, status, start_date, end_date)
WHERE o.code = 'QOR-HQ-01'
ON CONFLICT (organization_id, code) DO NOTHING;

-- Sites (2 per project, so the project filter has something to filter)
INSERT INTO sites (organization_id, project_id, code, name, address)
SELECT pr.organization_id, pr.id, s.code, s.name, s.address
FROM (VALUES
  ('PRJ-CMB-01', 'CMB-FDN', 'Tower B Foundation Works',   'Port City Plot 12, Colombo 01'),
  ('PRJ-CMB-01', 'CMB-POD', 'Tower B Podium & Car Park',  'Port City Plot 12, Colombo 01'),
  ('PRJ-GAL-02', 'GAL-NTH', 'Interchange North Ramp',     'Pinnaduwa, Galle'),
  ('PRJ-GAL-02', 'GAL-STH', 'Interchange South Ramp',     'Akmeemana, Galle')
) AS s(project_code, code, name, address)
JOIN projects pr ON pr.code = s.project_code
JOIN organizations o ON o.id = pr.organization_id AND o.code = 'QOR-HQ-01'
ON CONFLICT (project_id, code) DO NOTHING;

-- Warehouses (2 per D-012): the central yard from 001 + one site store
INSERT INTO warehouses (organization_id, name, code, location, capacity, warehouse_type, site_id)
SELECT si.organization_id, 'Tower B Site Store', 'WH-SITE-CMB-01', 'Tower B Foundation Works', 2500.00, 'SITE', si.id
FROM sites si
JOIN projects pr ON pr.id = si.project_id AND pr.code = 'PRJ-CMB-01'
WHERE si.code = 'CMB-FDN'
ON CONFLICT (code) DO NOTHING;
